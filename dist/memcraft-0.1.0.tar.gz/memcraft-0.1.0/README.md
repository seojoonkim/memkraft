# MemCraft 🧠⚒️

**The compound knowledge system for AI agents**

MemCraft turns AI agent memory from a cold-start search into a compounding knowledge graph. Every conversation makes the next one smarter.

Inspired by [GBrain](https://github.com/garrytan/gbrain) and [Rowboat](https://github.com/rowboatlabs/rowboat), built for any AI agent framework.

## Why MemCraft?

Most AI agents reconstruct context on demand — searching transcripts, re-reading files, starting cold every time. MemCraft maintains **long-lived knowledge** instead:

- **Context accumulates** over time (compound interest for memory)
- **Relationships are explicit** and inspectable
- **Knowledge is editable** by you, not hidden inside a model
- **Everything is plain Markdown** — no lock-in, no proprietary formats

## Core Concepts

### 🏗️ Memory Architecture

```
memory/
├── RESOLVER.md          # Classification decision tree (MECE)
├── TEMPLATES.md         # Compiled Truth + Timeline templates
├── entities/            # People, companies, concepts
├── live-notes/          # Persistent tracking targets
├── decisions/           # Decision records with reasoning
├── originals/           # Original ideas (no paraphrasing)
├── inbox/               # Quick capture before classification
├── tasks/               # Work-in-progress context
└── meetings/            # Meeting briefs and notes
```

### 🧬 Compiled Truth + Timeline

Every entity page uses a **dual-layer structure**:

- **Compiled Truth** (top, rewritable) — current state summary, always up-to-date
- **Timeline** (bottom, append-only) — historical record with source attribution

```markdown
# Garry Tan

## Executive Summary
YC CEO. Open-sourced GBrain, a knowledge graph system.

## State
- **Role:** CEO, Y Combinator
- **Key Context:** Advocates compound knowledge systems for AI agents

---

## Timeline

- **2026-04-11** | Entity first detected [Source: Simon, Telegram, 2026-04-11]
- **2026-04-10** | GBrain open-sourced under MIT license [Source: X/@garrytan]
```

### 🔍 Brain-First Lookup

For person/company/strategy questions, **always search memory first**, then web:

```
memory_search → grep → web_search (fallback only)
```

### 🔄 Dream Cycle

Nightly memory maintenance that automatically detects:
- Incomplete source attributions
- Thin entity pages needing enrichment
- Potential duplicate entities
- Overdue inbox items

### 📌 Live Notes

Track people, companies, or topics persistently. New information automatically updates the note:

```bash
memcraft track "Garry Tan" --type person
memcraft update "Garry Tan" --info "GBrain MIT license release" --source "X/@garrytan"
memcraft brief "Garry Tan"  # Meeting prep
```

### 📋 Meeting Brief

One command to compile everything about a person before a meeting:

```bash
memcraft brief "Garry Tan"
```

Pulls entity info + live notes + timeline + open threads + related decisions.

### 🏷️ Source Attribution

Every fact must include a source:

```markdown
[Source: {who}, {channel}, {datetime}]
```

No source = not trustworthy. Six months later, you'll know where it came from.

## Installation

```bash
pip install memcraft
```

## Quick Start

```bash
# Initialize memory structure in your project
memcraft init

# Track an entity
memcraft track "Garry Tan" --type person --source "X/@garrytan"

# Add information
memcraft update "Garry Tan" --info "YC CEO, GBrain creator" --source "X/@garrytan, 2026-04-10"

# Generate a meeting brief
memcraft brief "Garry Tan"

# Run Dream Cycle (nightly maintenance)
memcraft dream --dry-run

# List all tracked entities
memcraft list
```

## Architecture Comparison

| Feature | GBrain | Rowboat | MemCraft |
|---------|--------|---------|----------|
| Knowledge structure | Compiled Truth + Timeline | Obsidian vault | Compiled Truth + Timeline |
| Entity detection | Manual | Auto (email/calendar) | Auto (LLM + regex) |
| Live tracking | ❌ | ✅ Live Notes | ✅ Live Notes |
| Meeting prep | ❌ | ✅ | ✅ Meeting Brief |
| Source attribution | ✅ | ❌ | ✅ Required |
| Dream Cycle | ❌ | ❌ | ✅ Auto maintenance |
| Memory resolver | ❌ | ❌ | ✅ RESOLVER.md |
| Originals capture | ❌ | ❌ | ✅ Originals/ |
| Framework | Claude-specific | Desktop app | Framework-agnostic |
| Storage | Markdown | Markdown | Markdown |

## Philosophy

> "An agent without this loop answers from stale context every time. An agent with it gets smarter with every conversation." — Garry Tan

MemCraft takes this further: not just smarter conversations, but a **compounding knowledge system** where:

1. **Memory compounds** — each conversation builds on all prior ones
2. **Structure enforces quality** — RESOLVER prevents duplication, Source Attribution enforces trustworthiness
3. **Maintenance is automated** — Dream Cycle keeps memory healthy without manual effort
4. **Knowledge is portable** — plain Markdown, no lock-in, works with any agent framework

## Contributing

PRs welcome! See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT

---

**MemCraft** — *Forge your memory, compound your knowledge.*
